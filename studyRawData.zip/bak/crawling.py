from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd

def craw():
    # 드라이버 가져오기
    driver = webdriver.Chrome()

    # 사이트 열기
    # url = driver.get('https://www.koreabaseball.com/Schedule/Schedule.aspx')
    # url = driver.get('https://www.koreabaseball.com/Schedule/Schedule.aspx?seriesId=0,9')

    # 정규 시즌 콤보 박스 클릭
    # driver.find_element_by_xpath("//select[@id='ddlSeries']/option[text()='KBO 정규시즌 일정']").click()

    # 팀 선택
    # driver.find_element_by_xpath("//ul[@class='tab-schedule']/li[@attr-value = 'HH']").click()
    list_team = ['NC','OB','KT','LG','WO','HT','LT','SS','SK','HH']

    # 연도 리스트
    list_year = ['2018','2019', '2020', '2021']

    # 달 리스트
    list_month = ['03','04','05','06', '07', '08', '09', '10','11']

    # 검색결과 담을 리스트
    searchList = []

    # 연도 반복
    for team in list_team:
        # 사이트 오픈
        driver.get('https://www.koreabaseball.com/Schedule/Schedule.aspx?seriesId=0,9')
        urlpath = f"//ul[@class='tab-schedule']/li[@attr-value = '{team}']"
        driver.find_element_by_xpath(urlpath).click()
        for year in list_year:
            # 연도 바꾸기
            driver.find_element_by_xpath("//select[@id='ddlYear']/option[text()='" + str(year) + "']").click()

            searchList = []

            # 달 반복
            for month in list_month:
                # 달 선택
                driver.find_element_by_xpath("//select[@id='ddlMonth']/option[text()='" + str(month) + "']").click()

                # 결과
                html = driver.page_source
                soup = BeautifulSoup(html, 'html.parser')
                tblSchedule = soup.find('table', {'class': 'tbl'})
                trs = tblSchedule.find_all('tr')

                # 표 읽어오기
                for idx, tr in enumerate(trs):
                    if idx > 0:
                        tds = tr.find_all('td')

                        if len(tds) == 8:
                            tds.insert(0, searchList[-1][0])
                            temp = [year, tds[0], tds[1].text.strip(), tds[2].text.strip(), tds[7].text.strip()]
                        else:
                            day = tds[0].text.strip()
                            if day == '데이터가 없습니다.':
                                break
                            time = tds[1].text.strip()
                            play = tds[2].text.strip()
                            park = tds[7].text.strip()
                            temp = [year, day, time, play, park]

                        if tds[8].text.strip() == '-':
                            searchList.append(temp)

            # csv 만들기
            data = pd.DataFrame(searchList)
            data.columns = ['year', 'day', 'time', 'play', 'park']
            data.head()
            resultpath = '/Users/kkk/Study/team_rawData/' + team + '_' + year + '모든경기정보.csv'
            data.to_csv(resultpath, encoding='UTF-8-sig')
