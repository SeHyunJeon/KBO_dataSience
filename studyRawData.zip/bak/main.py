import math
import os
import csv
import crawling as cr

def app():
    # dateFormatConvert()
    # print(calcST(-5.4, 2.7))
    # cr.craw()

def dateFormatConvert():
    # 2020-01-01 00:00
    path = '/Users/kkk/Study/SURFACE_ASOS_HR_2018-2021_rawData.csv'
    resultPath = '/Users/kkk/Study/SURFACE_ASOS_HR_2018-2021_rawData2.csv'
    f = open(path, 'r', encoding='utf-8-sig')
    rdr = csv.reader(f)
    for line in rdr:
        line[1] = line[1].replace('-','')
        line[1] = line[1].replace(':','')
        line[1] = line[1].replace(' ', ',')
        print(line[1])
        AppendLine2CSV(resultPath, line)
    f.close()

# 불쾌지수 계산
def calcDiscomfort(t, rh):
    # Discomfort Index
    # t; 기온(섭씨)
    # rh; 상대습도(%)
    return round((1.8*t - 0.55*(1-rh/100)*((1.8*t)-26) + 32), 2)

# 체감온도 계산(Sensible Temperature)
def calcST(t, v):
    # SensibleTemperature
    # t; 기온
    # v; 풍속(m/s) => V(Km/h)로 환산해야 됨(* 3.6)
    # return round((13.12 + (0.6215*t) - (11.37*((v*3.6) ** 0.16)) + (0.3965 * ((v*3.6) ** 0.16) * t)), 2)
    return round((13.12 + (0.6215 * t) - (11.37 * ((v * 3.6) ** 0.16)) + (0.3965 * ((v * 3.6) ** 0.16) * t)), 2)

# csv 파일 합치기
def App_SummaryCSV():
    # /Users/kkk/Study/HR/*.csv
    # 설정해야 할 부분
    pathDir = '/Users/kkk/Study/HR/'
    resultPath = '/Users/kkk/Study/result.csv'

    pathList=[]
    for fileName in os.listdir(pathDir):
        pathList.append(os.path.join(pathDir, fileName))

    for path in pathList:
        print(path)
        f = open(path, 'r', encoding='euc-kr')
        header = next(f) # 헤더 제외
        reader = csv.reader(f)
        for line in reader:
            AppendLine2CSV(resultPath, line)
        f.close()

# 컬럼 선택 후 결과 출력
def App_SelectCol(colindexList):
    resultPath = '/Users/kkk/Study/result.csv'
    print(resultPath)
    f = open(resultPath, 'r', encoding='utf-8-sig')
    reader = csv.reader(f)
    for line in reader:
        AppendLine2CSV(resultPath, getSelectCol(line, colindexList))
    f.close()

def getSelectCol(line, colindexList):
    tmpline = []
    for i in colindexList:
        tmpline.append(line[i])
    return tmpline

def AppendLine2CSV(path, line):
    f = open(path, 'a', encoding='utf-8-sig')
    wr = csv.writer(f)
    wr.writerow(line)
    f.close()

if __name__ == '__main__':
    App_SelectCol([0, 1]) # 지정한 컬럼의 데이터 입력
    print('\n\n========== End ==========')